#ifndef __R_FOE_H__
#define __R_FOE_H__

#include "cocos2d.h"

class RFoe : public cocos2d::Layer {

public:

	virtual bool init();

	CREATE_FUNC(RFoe);

};
#endif // ! __R_FOE_H__
