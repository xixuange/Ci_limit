#ifndef __R_PLAYER_H__
#define __R_PLAYER_H__

#include "cocos2d.h"

class RPlayer : public cocos2d::Layer {

public:

	virtual bool init();

	CREATE_FUNC(RPlayer);

};
#endif // !__R_PLAYER_H__
