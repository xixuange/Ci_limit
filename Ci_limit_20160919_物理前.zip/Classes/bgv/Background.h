#ifndef __BACKGROUND_H__
#define __BACKGROUND_H__

#include"cocos2d.h"

class Background : public cocos2d::Layer {

public:

	virtual bool init();

	CREATE_FUNC(Background);

};

#endif // !__BACKGROUND_H__
